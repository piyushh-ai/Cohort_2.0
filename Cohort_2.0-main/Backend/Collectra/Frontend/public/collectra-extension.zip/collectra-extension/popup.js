const API_BASE = "https://collectra.online/api";
const APP_URL  = "https://collectra.online";

// ── DOM refs ──────────────────────────────────────────
const screenLogin   = document.getElementById("screen-login");
const screenSave    = document.getElementById("screen-save");
const screenSuccess = document.getElementById("screen-success");
const openLoginBtn  = document.getElementById("open-login-btn");
const logoutBtn     = document.getElementById("logout-btn");
const saveBtn       = document.getElementById("save-btn");
const viewVaultBtn  = document.getElementById("view-vault-btn");
const pageTitle     = document.getElementById("page-title");
const pageUrl       = document.getElementById("page-url");
const pageFavicon   = document.getElementById("page-favicon");
const collSelect    = document.getElementById("collection-select");
const errorMsg      = document.getElementById("error-msg");
const errorText     = document.getElementById("error-text");
const successColName = document.getElementById("success-collection-name");
const userNameLabel  = document.getElementById("user-name-label");
const userAvatarWrap = document.getElementById("user-avatar-wrap");

// ── Init ──────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  const token = await syncFromLocalStorage();

  if (!token) {
    showScreen("login");
    return;
  }

  const user = await verifyAndGetUser(token);
  if (!user) {
    await clearToken();
    showScreen("login");
    return;
  }

  // Populate user chip
  setUserChip(user);

  showScreen("save");
  await Promise.all([loadTab(), loadCollections(token)]);
});

// ── Sync token from open Collectra tab ───────────────
async function syncFromLocalStorage() {
  try {
    const tabs = await chrome.tabs.query({ url: `${APP_URL}/*` });
    if (tabs.length === 0) {
      // Try render.com fallback (legacy)
      const legacyTabs = await chrome.tabs.query({ url: "https://collectra-ae2v.onrender.com/*" });
      if (legacyTabs.length === 0) return null;
      return extractTokenFromTab(legacyTabs[0].id);
    }
    return extractTokenFromTab(tabs[0].id);
  } catch {
    return null;
  }
}

async function extractTokenFromTab(tabId) {
  try {
    const result = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => localStorage.getItem("collectra_token"),
    }).catch(() => null);

    const token = result?.[0]?.result;
    if (token) {
      await saveToken(token);
      return token;
    } else {
      await clearToken();
      return null;
    }
  } catch {
    return null;
  }
}

// ── Verify token + get user data ──────────────────────
async function verifyAndGetUser(token) {
  try {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return null;
    const data = await res.json();
    // Return user object (adjust key based on your API response)
    return data.user || data.data || data || null;
  } catch {
    return null;
  }
}

// ── Populate user chip ────────────────────────────────
function setUserChip(user) {
  const name = user?.username || user?.name || user?.email || "User";
  userNameLabel.textContent = name;

  // Clear previous content
  userAvatarWrap.innerHTML = "";

  if (user?.googleProfilePicture || user?.profilePicture) {
    const img = document.createElement("img");
    img.src = user.profilePicture || user.googleProfilePicture;
    img.alt = name;
    img.referrerPolicy = "no-referrer";
    img.onerror = () => setInitialsAvatar(name);
    userAvatarWrap.appendChild(img);
  } else {
    setInitialsAvatar(name);
  }
}

function setInitialsAvatar(name) {
  userAvatarWrap.innerHTML = "";
  const span = document.createElement("span");
  span.textContent = (name || "U").slice(0, 2).toUpperCase();
  span.style.cssText = "font-family:'Syne',sans-serif;font-size:7px;font-weight:800;color:#fff;";
  userAvatarWrap.appendChild(span);
}

// ── Screen manager ────────────────────────────────────
function showScreen(name) {
  screenLogin.classList.add("hidden");
  screenSave.classList.add("hidden");
  screenSuccess.classList.add("hidden");
  if (name === "login")   screenLogin.classList.remove("hidden");
  if (name === "save")    screenSave.classList.remove("hidden");
  if (name === "success") screenSuccess.classList.remove("hidden");
}

// ── Token helpers ─────────────────────────────────────
function getStoredToken() {
  return new Promise(res =>
    chrome.storage.local.get("collectra_token", d => res(d.collectra_token || null))
  );
}
function saveToken(token) {
  return new Promise(res =>
    chrome.storage.local.set({ collectra_token: token }, res)
  );
}
function clearToken() {
  return new Promise(res =>
    chrome.storage.local.remove("collectra_token", res)
  );
}

// ── Load current tab ──────────────────────────────────
async function loadTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  pageTitle.textContent = tab.title || "Untitled";
  try {
    pageUrl.textContent = new URL(tab.url).hostname || tab.url;
  } catch {
    pageUrl.textContent = tab.url;
  }

  if (tab.favIconUrl) {
    const img = document.createElement("img");
    img.src = tab.favIconUrl;
    img.onerror = () => {};
    pageFavicon.innerHTML = "";
    pageFavicon.appendChild(img);
  }
}

// ── Load collections ──────────────────────────────────
async function loadCollections(token) {
  try {
    const res = await fetch(`${API_BASE}/collections`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      if (res.status === 401) { await clearToken(); showScreen("login"); }
      return;
    }
    const data = await res.json();
    (data.data || []).forEach(col => {
      const opt = document.createElement("option");
      opt.value = col._id;
      opt.textContent = col.name;
      collSelect.appendChild(opt);
    });
  } catch {
    // silently fail
  }
}

// ── Save ──────────────────────────────────────────────
saveBtn.addEventListener("click", async () => {
  const token = await getStoredToken();
  if (!token) { showScreen("login"); return; }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) return;

  if (
    tab.url.startsWith("chrome://") ||
    tab.url.startsWith("chrome-extension://") ||
    tab.url.startsWith("about:")
  ) {
    showError("Cannot save browser pages. Navigate to a website first.");
    return;
  }

  hideError();
  setSaving(true);

  try {
    const body = new FormData();
    body.append("url", tab.url);
    if (collSelect.value) body.append("collectionId", collSelect.value);

    const res = await fetch(`${API_BASE}/items`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body,
    });

    const data = await res.json();

    if (!res.ok) {
      if (res.status === 401) { await clearToken(); showScreen("login"); return; }
      throw new Error(data.message || "Failed to save item.");
    }

    const colLabel = collSelect.options[collSelect.selectedIndex]?.text;
    successColName.textContent = collSelect.value
      ? `Added to "${colLabel}"`
      : "Added to Uncategorized";
    showScreen("success");
  } catch (err) {
    showError(err.message || "Something went wrong. Please try again.");
  } finally {
    setSaving(false);
  }
});

// ── Buttons ───────────────────────────────────────────
logoutBtn.addEventListener("click", async () => {
  await clearToken();
  showScreen("login");
});
openLoginBtn.addEventListener("click", () =>
  chrome.tabs.create({ url: APP_URL })
);
viewVaultBtn.addEventListener("click", () =>
  chrome.tabs.create({ url: APP_URL })
);

// ── Helpers ───────────────────────────────────────────
function setSaving(on) {
  saveBtn.disabled = on;
  saveBtn.innerHTML = on
    ? `<span class="spinner"></span> Saving…`
    : `<svg width="13" height="13" viewBox="0 0 16 16" fill="currentColor">
         <path d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2z"/>
       </svg> Save to Vault`;
}
function showError(msg) {
  errorText.textContent = msg;
  errorMsg.classList.remove("hidden");
}
function hideError() {
  errorMsg.classList.add("hidden");
}
